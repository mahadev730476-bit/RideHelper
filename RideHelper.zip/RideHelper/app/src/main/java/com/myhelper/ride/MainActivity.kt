package com.myhelper.ride

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("cfg", MODE_PRIVATE)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 96, 48, 48)
        }
        fun tv(s: String, size: Float = 16f) = TextView(this).apply { text = s; textSize = size; setPadding(0, 16, 0, 16) }

        layout.addView(tv("Ride Helper", 26f))
        layout.addView(tv("Step 1: Accessibility ON karo (Ride Helper dhundho)"))
        layout.addView(Button(this).apply {
            text = "Accessibility Settings kholo"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })

        layout.addView(tv("Step 2: Minimum fare (₹). 0 = har ride accept"))
        val fareBox = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER
            setText(prefs.getInt("minFare", 0).toString())
        }
        layout.addView(fareBox)

        val sw = Switch(this).apply {
            text = "Auto Accept ON"
            isChecked = prefs.getBoolean("enabled", false)
            textSize = 18f
        }
        layout.addView(sw)

        layout.addView(Button(this).apply {
            text = "Save"
            setOnClickListener {
                prefs.edit()
                    .putInt("minFare", fareBox.text.toString().toIntOrNull() ?: 0)
                    .putBoolean("enabled", sw.isChecked)
                    .apply()
                Toast.makeText(this@MainActivity, "Saved", Toast.LENGTH_SHORT).show()
            }
        })
        layout.addView(tv("Step 3: Rapido Captain kholo aur online jao. Battery optimization 'No restrictions' rakho."))
        setContentView(ScrollView(this).apply { addView(layout) })
    }
}
