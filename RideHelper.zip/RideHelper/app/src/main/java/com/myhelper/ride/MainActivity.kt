package com.myhelper.ride

import android.app.Activity
import android.content.Intent
import android.content.SharedPreferences
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : Activity() {

    private val BG = 0xFF0E0F13.toInt()
    private val CARD = 0xFF1A1C23.toInt()
    private val FIELD = 0xFF22252E.toInt()
    private val BORDER = 0xFF2E313E.toInt()
    private val ACCENT = 0xFFFFC400.toInt()
    private val GREEN = 0xFF22C55E.toInt()
    private val RED = 0xFFEF4444.toInt()
    private val MUTED = 0xFF9CA3AF.toInt()

    private lateinit var prefs: SharedPreferences
    private lateinit var scroll: ScrollView
    private lateinit var topDot: View
    private lateinit var topText: TextView
    private val navViews = mutableListOf<TextView>()
    private var tab = 0

    private val navItems = listOf("🏠" to "Home", "₹" to "Fare", "📍" to "KM", "🕘" to "History", "⚙" to "Settings")

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun round(color: Int, r: Int, stroke: Int? = null) = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(r).toFloat()
        if (stroke != null) setStroke(dp(1), stroke)
    }

    private fun text(s: String, size: Float, color: Int = Color.WHITE, bold: Boolean = false) =
        TextView(this).apply {
            text = s; textSize = size; setTextColor(color)
            if (bold) setTypeface(null, Typeface.BOLD)
        }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = round(CARD, 18, BORDER)
        setPadding(dp(18), dp(16), dp(18), dp(16))
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(14) }
    }

    private fun page(title: String, sub: String): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(18), dp(8), dp(18), dp(24))
        addView(text(title, 26f, Color.WHITE, true))
        addView(text(sub, 13f, MUTED))
    }

    private fun pill(txt: String, bg: Int, fg: Int) = TextView(this).apply {
        text = txt; textSize = 12.5f; setTextColor(fg); setTypeface(null, Typeface.BOLD)
        background = round(bg, 30)
        setPadding(dp(12), dp(6), dp(12), dp(6))
    }

    private fun actionBtn(label: String, color: Int = Color.WHITE, onClick: () -> Unit) = TextView(this).apply {
        text = label; textSize = 15f; setTextColor(color); gravity = Gravity.CENTER
        setTypeface(null, Typeface.BOLD)
        background = round(CARD, 16, BORDER)
        layoutParams = LinearLayout.LayoutParams(-1, dp(52)).apply { topMargin = dp(12) }
        setOnClickListener { onClick() }
    }

    // ---------- lifecycle ----------
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Store.prefs(this)
        window.statusBarColor = BG
        window.navigationBarColor = CARD

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(BG)
        }

        // top bar
        val top = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(36), dp(16), dp(10))
        }
        top.addView(ImageView(this).apply {
            setImageResource(R.drawable.ic_logo)
            layoutParams = LinearLayout.LayoutParams(dp(38), dp(38))
        })
        top.addView(text("RIDE HELPER", 18f, ACCENT, true).apply {
            setPadding(dp(10), 0, 0, 0)
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
        })
        topDot = View(this).apply {
            layoutParams = LinearLayout.LayoutParams(dp(10), dp(10)).apply { rightMargin = dp(6) }
        }
        topText = text("", 12f, MUTED)
        top.addView(topDot); top.addView(topText)
        root.addView(top)

        scroll = ScrollView(this).apply {
            layoutParams = LinearLayout.LayoutParams(-1, 0, 1f)
        }
        root.addView(scroll)

        // bottom nav
        val nav = LinearLayout(this).apply {
            setBackgroundColor(CARD)
            setPadding(0, dp(6), 0, dp(6))
        }
        navItems.forEachIndexed { i, (icon, label) ->
            val v = TextView(this).apply {
                text = "$icon\n$label"; textSize = 11f; gravity = Gravity.CENTER
                setPadding(0, dp(6), 0, dp(6))
                layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
                setOnClickListener { show(i) }
            }
            navViews.add(v); nav.addView(v)
        }
        root.addView(nav)
        setContentView(root)
        show(0)
    }

    override fun onResume() {
        super.onResume()
        show(tab)
    }

    private fun accessibilityOn(): Boolean {
        val s = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: ""
        return s.contains("$packageName/")
    }

    private fun show(i: Int) {
        tab = i
        navViews.forEachIndexed { idx, v -> v.setTextColor(if (idx == i) ACCENT else MUTED) }
        refreshTop()
        val p = when (i) {
            0 -> homePage()
            1 -> farePage()
            2 -> kmPage()
            3 -> historyPage()
            else -> settingsPage()
        }
        scroll.removeAllViews()
        scroll.addView(p, ViewGroup.LayoutParams(-1, -2))
        scroll.scrollTo(0, 0)
    }

    private fun refreshTop() {
        val acc = accessibilityOn()
        val on = prefs.getBoolean("enabled", false)
        when {
            !acc -> { topDot.background = round(RED, 5); topText.text = "Accessibility OFF" }
            !on -> { topDot.background = round(ACCENT, 5); topText.text = "Paused" }
            else -> { topDot.background = round(GREEN, 5); topText.text = "Active" }
        }
    }

    // ---------- HOME ----------
    private fun homePage(): View {
        val p = page("Home", "Ek tap mein auto accept ON/OFF")
        val on = prefs.getBoolean("enabled", false)

        p.addView(TextView(this).apply {
            text = if (on) "⚡\nON" else "⚡\nOFF"
            textSize = 30f; gravity = Gravity.CENTER; setTypeface(null, Typeface.BOLD)
            setTextColor(if (on) Color.BLACK else MUTED)
            background = if (on) round(ACCENT, 80) else round(CARD, 80, ACCENT)
            layoutParams = LinearLayout.LayoutParams(dp(160), dp(160)).apply {
                gravity = Gravity.CENTER_HORIZONTAL; topMargin = dp(22); bottomMargin = dp(8)
            }
            setOnClickListener { prefs.edit().putBoolean("enabled", !on).apply(); show(0) }
        })

        val sc = card()
        val acc = accessibilityOn()
        sc.addView(text(
            if (!acc) "⚠ Accessibility OFF" else if (on) "✅ Active" else "⏸ Paused",
            17f, if (!acc) RED else if (on) GREEN else ACCENT, true))
        sc.addView(text(
            if (!acc) "Yahan tap karke Ride Helper ON karo"
            else if (on) "Rapido par ride request ka wait kar raha hai"
            else "Upar ke button se ON karo", 12f, MUTED))
        sc.setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        p.addView(sc)

        val row = LinearLayout(this).apply {
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(14) }
        }
        fun stat(label: String, value: Int, color: Int, left: Boolean) = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            background = round(CARD, 18, BORDER)
            setPadding(dp(10), dp(16), dp(10), dp(16))
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f).apply {
                if (left) rightMargin = dp(7) else leftMargin = dp(7)
            }
            addView(text(value.toString(), 34f, color, true))
            addView(text(label, 12f, MUTED))
        }
        row.addView(stat("Aaj accept", Store.todayCount(this, "count"), GREEN, true))
        row.addView(stat("Aaj skip", Store.todayCount(this, "skipCount"), RED, false))
        p.addView(row)

        val fc = card()
        val f = prefs.getInt("minFare", 0)
        val mp = prefs.getFloat("maxPickup", 0f)
        val md = prefs.getFloat("maxDrop", 0f)
        fc.addView(text("ACTIVE FILTERS", 12f, MUTED, true))
        fc.addView(text("₹ Min fare:  " + (if (f == 0) "Any" else "₹$f"), 15f).apply { setPadding(0, dp(8), 0, 0) })
        fc.addView(text("📍 Max pickup:  " + (if (mp == 0f) "Any" else "$mp km"), 15f).apply { setPadding(0, dp(4), 0, 0) })
        fc.addView(text("🏁 Max drop:  " + (if (md == 0f) "Any" else "$md km"), 15f).apply { setPadding(0, dp(4), 0, 0) })
        p.addView(fc)
        return p
    }

    // ---------- generic stepper ----------
    private fun stepperCard(
        title: String, desc: String, get: () -> Float, set: (Float) -> Unit,
        step: Float, chips: List<Float>, fmt: (Float) -> String
    ): View {
        val c = card()
        c.addView(text(title.uppercase(), 12f, MUTED, true))
        val value = text(fmt(get()), 40f, Color.WHITE, true).apply {
            gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
        }
        fun upd(v: Float) {
            val nv = maxOf(0f, Math.round(v * 10f) / 10f)
            set(nv); value.text = fmt(nv)
        }
        fun btn(label: String, d: Float) = TextView(this).apply {
            text = label; textSize = 26f; setTextColor(Color.BLACK)
            setTypeface(null, Typeface.BOLD); gravity = Gravity.CENTER
            background = round(ACCENT, 28)
            layoutParams = LinearLayout.LayoutParams(dp(56), dp(56))
            setOnClickListener { upd(get() + d) }
        }
        val row = LinearLayout(this).apply {
            gravity = Gravity.CENTER; setPadding(0, dp(10), 0, dp(10))
        }
        row.addView(btn("−", -step)); row.addView(value); row.addView(btn("+", step))
        c.addView(row)
        val cr = LinearLayout(this).apply { gravity = Gravity.CENTER }
        for (v in chips) {
            cr.addView(TextView(this).apply {
                text = fmt(v); textSize = 13f; setTextColor(ACCENT); gravity = Gravity.CENTER
                background = round(FIELD, 12, 0x55FFC400)
                layoutParams = LinearLayout.LayoutParams(0, dp(40), 1f).apply {
                    leftMargin = dp(3); rightMargin = dp(3)
                }
                setOnClickListener { upd(v) }
            })
        }
        c.addView(cr)
        c.addView(text(desc, 12f, MUTED).apply { setPadding(0, dp(10), 0, 0) })
        return c
    }

    // ---------- FARE ----------
    private fun farePage(): View {
        val p = page("Fare", "Kam paise ki ride skip hogi")
        p.addView(stepperCard(
            "Minimum fare",
            "Is se kam fare wali ride accept nahi hogi. 'Any' = fare check band.",
            { prefs.getInt("minFare", 0).toFloat() },
            { prefs.edit().putInt("minFare", it.toInt()).apply() },
            5f, listOf(0f, 30f, 50f, 70f, 100f),
            { if (it.toInt() == 0) "Any" else "₹${it.toInt()}" }
        ))
        return p
    }

    // ---------- KM ----------
    private fun kmPage(): View {
        val p = page("Distance (KM)", "Pickup aur drop ki doori set karo")
        p.addView(stepperCard(
            "Max pickup distance",
            "Customer is se zyada door ho to ride skip hogi. 'Any' = check band.",
            { prefs.getFloat("maxPickup", 0f) },
            { prefs.edit().putFloat("maxPickup", it).apply() },
            0.5f, listOf(0f, 1f, 2f, 3f, 5f),
            { if (it == 0f) "Any" else "$it km" }
        ))
        p.addView(stepperCard(
            "Max drop distance",
            "Safar is se lamba ho to ride skip hogi. 'Any' = check band.",
            { prefs.getFloat("maxDrop", 0f) },
            { prefs.edit().putFloat("maxDrop", it).apply() },
            1f, listOf(0f, 5f, 10f, 20f, 40f),
            { if (it == 0f) "Any" else "$it km" }
        ))
        p.addView(text("Note: screen par pehla km = pickup, dusra km = drop maana jata hai.", 12f, MUTED).apply {
            setPadding(dp(4), dp(14), dp(4), 0)
        })
        return p
    }

    // ---------- HISTORY ----------
    private fun historyPage(): View {
        val p = page("History", "Accept aur skip hui rides")
        val items = Store.history(this)
        if (items.isEmpty()) {
            p.addView(card().apply {
                gravity = Gravity.CENTER
                addView(text("Abhi koi ride nahi", 15f, MUTED))
            })
            return p
        }
        val fmt = SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault())
        for (h in items) {
            val ok = h[0] == "A"
            val c = card()
            val r = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
            val left = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
            }
            val km = listOf(
                if (h[3].isNotEmpty()) "📍${h[3]} km" else "",
                if (h[4].isNotEmpty()) "🏁${h[4]} km" else ""
            ).filter { it.isNotEmpty() }.joinToString("  ")
            left.addView(text("₹${h[2]}   $km", 16f, Color.WHITE, true))
            left.addView(text(fmt.format(Date(h[1].toLongOrNull() ?: 0L)), 12f, MUTED))
            r.addView(left)
            r.addView(pill(if (ok) "✔ Accepted" else "✖ ${h[5]}", if (ok) 0x262ECC71 else 0x26EF4444, if (ok) GREEN else RED))
            c.addView(r)
            p.addView(c)
        }
        p.addView(actionBtn("🗑  History clear karo", RED) {
            Store.clearHistory(this); show(3)
        })
        return p
    }

    // ---------- SETTINGS ----------
    private fun toggleRow(title: String, sub: String, key: String, def: Boolean): View {
        val c = card()
        val r = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
        }
        col.addView(text(title, 16f, Color.WHITE, true))
        col.addView(text(sub, 12f, MUTED))
        val sw = Switch(this).apply {
            isChecked = prefs.getBoolean(key, def)
            thumbTintList = ColorStateList(
                arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()),
                intArrayOf(ACCENT, 0xFF888888.toInt()))
            trackTintList = ColorStateList(
                arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()),
                intArrayOf(0x66FFC400, 0xFF333640.toInt()))
            setOnCheckedChangeListener { _, v -> prefs.edit().putBoolean(key, v).apply() }
        }
        r.addView(col); r.addView(sw)
        c.addView(r)
        return c
    }

    private fun settingsPage(): View {
        val p = page("Settings", "App ki settings")

        p.addView(toggleRow("Vibrate", "Ride accept hone par phone vibrate kare", "vibrate", true))

        val pc = card()
        pc.addView(text("RAPIDO PACKAGE NAME", 12f, MUTED, true))
        val box = EditText(this).apply {
            setText(prefs.getString("pkg", "com.rapido.rider"))
            setTextColor(Color.WHITE); textSize = 15f
            background = round(FIELD, 12)
            setPadding(dp(14), dp(12), dp(14), dp(12))
            setSingleLine(true)
            addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(s: Editable?) {
                    prefs.edit().putString("pkg", s.toString().trim()).apply()
                }
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            })
        }
        pc.addView(box.apply {
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) }
        })
        pc.addView(text("Naam mein 'rapido' ho to apne aap chalega. Na chale to yahan sahi naam daalo.", 12f, MUTED)
            .apply { setPadding(0, dp(8), 0, 0) })
        p.addView(pc)

        p.addView(actionBtn("♿  Accessibility Settings") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        p.addView(actionBtn("🔋  Battery: No restrictions karo") {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        })
        p.addView(actionBtn("🔄  Aaj ke counter reset karo") {
            Store.resetToday(this); Toast.makeText(this, "Reset ho gaya", Toast.LENGTH_SHORT).show()
        })

        // ---- DEBUG CARD ----
        val dc = card()
        dc.addView(text("DEBUG (ride na accept ho to yahan dekho)", 12f, MUTED, true))
        val lastPkg = prefs.getString("lastPkg", "") ?: ""
        val lastPkgTime = prefs.getLong("lastPkgTime", 0L)
        val ago1 = if (lastPkgTime > 0) ((System.currentTimeMillis() - lastPkgTime) / 1000) else -1
        dc.addView(text("Abhi khula hua app:", 13f, MUTED).apply { setPadding(0, dp(10), 0, 0) })
        dc.addView(text(if (lastPkg.isEmpty()) "(abhi tak kuch nahi dekha)" else "$lastPkg  (${ago1}s pehle)", 14f, Color.WHITE, true))

        val dump = prefs.getString("lastDump", "") ?: ""
        val found = prefs.getBoolean("lastFound", false)
        val dumpTime = prefs.getLong("lastDumpTime", 0L)
        val winCount = prefs.getInt("lastWindowCount", -1)
        dc.addView(text("Accept button mila (windows scan: " + (if (winCount < 0) "-" else winCount.toString()) + "):", 13f, MUTED).apply { setPadding(0, dp(14), 0, 0) })
        dc.addView(text(if (dumpTime == 0L) "(Rapido abhi tak khula hi nahi dekha)" else if (found) "✅ HAAN" else "❌ NAHI", 15f, if (found) GREEN else RED, true))
        dc.addView(text("Rapido screen par dikha text (sample):", 13f, MUTED).apply { setPadding(0, dp(14), 0, 0) })
        dc.addView(text(if (dump.isEmpty()) "(kuch nahi mila)" else dump, 12f, Color.WHITE).apply {
            setPadding(0, dp(4), 0, 0)
        })
        dc.addView(actionBtn("🔄  Refresh debug info") { show(4) })
        p.addView(dc)

        p.addView(text("Ride Helper v2.2", 12f, MUTED).apply {
            gravity = Gravity.CENTER; setPadding(0, dp(20), 0, 0)
        })
        return p
    }
}
