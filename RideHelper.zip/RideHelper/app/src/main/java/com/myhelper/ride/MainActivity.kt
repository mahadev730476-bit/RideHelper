package com.myhelper.ride

import android.app.Activity
import android.content.Intent
import android.content.SharedPreferences
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.widget.*
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : Activity() {

    // ---- Palette ----
    private val BG = 0xFF0B0C10.toInt()
    private val BAR = 0xFF15171E.toInt()
    private val CARD = 0xFF1A1C24.toInt()
    private val CARD2 = 0xFF20222C.toInt()
    private val FIELD = 0xFF262935.toInt()
    private val BORDER = 0xFF2E313E.toInt()
    private val ACCENT = 0xFFFFC400.toInt()
    private val ACCENT_DIM = 0x33FFC400
    private val GREEN = 0xFF2ECC71.toInt()
    private val GREEN_DIM = 0x262ECC71
    private val RED = 0xFFEF4444.toInt()
    private val RED_DIM = 0x26EF4444
    private val MUTED = 0xFF9AA0AC.toInt()
    private val WHITE = Color.WHITE

    private lateinit var prefs: SharedPreferences
    private lateinit var scroll: ScrollView
    private lateinit var topDot: View
    private lateinit var topText: TextView
    private val navViews = mutableListOf<LinearLayout>()
    private val navIcons = mutableListOf<TextView>()
    private val navLabels = mutableListOf<TextView>()
    private val navIndicators = mutableListOf<View>()
    private var tab = 0

    private val navItems = listOf("🏠" to "Home", "₹" to "Fare", "📍" to "KM", "🕘" to "History", "⚙" to "Settings")

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun dpf(v: Float) = v * resources.displayMetrics.density

    private fun round(color: Int, r: Int, stroke: Int? = null, strokeW: Int = 1): GradientDrawable =
        GradientDrawable().apply {
            setColor(color); cornerRadius = dp(r).toFloat()
            if (stroke != null) setStroke(dp(strokeW), stroke)
        }

    private fun elevate(v: View, dpVal: Int) {
        // Shadow hata diya gaya — kuch phones par ye content ko invisible kar raha tha.
        // Ab ye function kuch nahi karta, sirf naam rakha hai taaki baaki code na tootay.
    }

    private fun text(s: String, size: Float, color: Int = WHITE, bold: Boolean = false, letterSp: Float = 0f) =
        TextView(this).apply {
            text = s; textSize = size; setTextColor(color)
            if (bold) setTypeface(null, Typeface.BOLD)
            if (letterSp != 0f) letterSpacing = letterSp
        }

    private fun card(pad: Int = 18, radius: Int = 18): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = round(CARD, radius, BORDER)
        setPadding(dp(pad), dp(pad - 2), dp(pad), dp(pad - 2))
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(14) }
        elevate(this, 2)
    }

    private fun sectionLabel(s: String) = text(s, 11.5f, MUTED, true, 0.08f)

    private fun page(title: String, sub: String): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(18), dp(10), dp(18), dp(28))
        addView(text(title, 25f, WHITE, true))
        addView(text(sub, 13f, MUTED).apply { setPadding(0, dp(3), 0, 0) })
    }

    private fun actionBtn(icon: String, label: String, color: Int = WHITE, onClick: () -> Unit) =
        LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = round(CARD2, 16, BORDER)
            setPadding(dp(18), dp(15), dp(18), dp(15))
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) }
            elevate(this, 1)
            addView(TextView(this@MainActivity).apply { text = icon; textSize = 18f })
            addView(text(label, 15f, color, true).apply {
                setPadding(dp(12), 0, 0, 0)
                layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
            })
            addView(text("›", 20f, MUTED, true))
            isClickable = true
            setOnClickListener { onClick() }
        }

    private fun pill(txt: String, bg: Int, fg: Int) = TextView(this).apply {
        text = txt; textSize = 12.5f; setTextColor(fg); setTypeface(null, Typeface.BOLD)
        background = round(bg, 30)
        setPadding(dp(12), dp(6), dp(12), dp(6))
    }

    // ---------- lifecycle ----------
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Store.prefs(this)
        window.statusBarColor = BAR
        window.navigationBarColor = BAR

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(BG)
        }

        // ---- top app bar ----
        val top = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            background = round(BAR, 0)
            setPadding(dp(18), dp(38), dp(18), dp(14))
            elevate(this, 6)
        }
        val logoWrap = FrameLayout(this).apply {
            background = round(0xFF0E0F13.toInt(), 22, ACCENT)
            layoutParams = LinearLayout.LayoutParams(dp(42), dp(42))
        }
        logoWrap.addView(ImageView(this).apply {
            setImageResource(R.drawable.ic_logo)
            layoutParams = FrameLayout.LayoutParams(dp(42), dp(42))
        })
        top.addView(logoWrap)
        val titleCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = dp(12) }
        }
        titleCol.addView(text("RIDE HELPER", 17f, ACCENT, true, 0.05f))
        titleCol.addView(text("Smart accept assistant", 11f, MUTED))
        top.addView(titleCol)

        val statusChip = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            background = round(CARD2, 20, BORDER)
            setPadding(dp(12), dp(7), dp(14), dp(7))
        }
        topDot = View(this).apply {
            layoutParams = LinearLayout.LayoutParams(dp(8), dp(8)).apply { rightMargin = dp(7) }
        }
        topText = text("", 11.5f, MUTED, true)
        statusChip.addView(topDot); statusChip.addView(topText)
        top.addView(statusChip)
        root.addView(top)

        scroll = ScrollView(this).apply {
            layoutParams = LinearLayout.LayoutParams(-1, 0, 1f)
            overScrollMode = View.OVER_SCROLL_NEVER
        }
        root.addView(scroll)

        // ---- bottom nav ----
        val navWrap = FrameLayout(this)
        val navBg = View(this).apply { background = round(BAR, 0) }
        navWrap.addView(navBg, FrameLayout.LayoutParams(-1, -1))
        val nav = LinearLayout(this).apply {
            setPadding(dp(4), dp(10), dp(4), dp(10))
        }
        navItems.forEachIndexed { i, (icon, label) ->
            val cell = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
                setPadding(0, dp(4), 0, dp(2))
                isClickable = true
                setOnClickListener { show(i) }
            }
            val ind = View(this).apply {
                background = round(ACCENT, 4)
                layoutParams = LinearLayout.LayoutParams(dp(18), dp(3)).apply { bottomMargin = dp(5) }
                alpha = 0f
            }
            val ic = text(icon, 17f, MUTED)
            val lb = text(label, 10.5f, MUTED, true)
            cell.addView(ind); cell.addView(ic); cell.addView(lb)
            navViews.add(cell); navIcons.add(ic); navLabels.add(lb); navIndicators.add(ind)
            nav.addView(cell)
        }
        navWrap.addView(nav)
        elevate(navWrap, 10)
        root.addView(navWrap)

        setContentView(root)
        show(0)
    }

    override fun onResume() {
        super.onResume()
        show(tab)
    }

    private fun accessibilityOn(): Boolean {
        val s = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: ""
        return s.contains("$packageName/")
    }

    private fun show(i: Int) {
        tab = i
        navViews.forEachIndexed { idx, _ ->
            val on = idx == i
            navIcons[idx].setTextColor(if (on) ACCENT else MUTED)
            navLabels[idx].setTextColor(if (on) ACCENT else MUTED)
            navIndicators[idx].alpha = if (on) 1f else 0f
        }
        refreshTop()
        val p = when (i) {
            0 -> homePage()
            1 -> farePage()
            2 -> kmPage()
            3 -> historyPage()
            else -> settingsPage()
        }
        scroll.removeAllViews()
        scroll.addView(p, ViewGroup.LayoutParams(-1, -2))
        scroll.scrollTo(0, 0)
    }

    private fun refreshTop() {
        val acc = accessibilityOn()
        val on = prefs.getBoolean("enabled", false)
        when {
            !acc -> { topDot.background = round(RED, 5); topText.text = "OFF" }
            !on -> { topDot.background = round(ACCENT, 5); topText.text = "PAUSED" }
            else -> { topDot.background = round(GREEN, 5); topText.text = "LIVE" }
        }
    }

    // ---------- HOME ----------
    private fun homePage(): View {
        val p = page("Home", "Ek tap mein auto accept ON/OFF")
        val on = prefs.getBoolean("enabled", false)

        val btnWrap = FrameLayout(this).apply {
            layoutParams = LinearLayout.LayoutParams(dp(176), dp(176)).apply {
                gravity = Gravity.CENTER_HORIZONTAL; topMargin = dp(26); bottomMargin = dp(10)
            }
        }
        val ring = View(this).apply {
            background = round(0x00000000, 88, if (on) ACCENT else BORDER, 2)
            layoutParams = FrameLayout.LayoutParams(dp(176), dp(176))
        }
        val inner = TextView(this).apply {
            text = if (on) "⚡\nON" else "⚡\nOFF"
            textSize = 28f; gravity = Gravity.CENTER; setTypeface(null, Typeface.BOLD)
            setTextColor(if (on) 0xFF1A1300.toInt() else MUTED)
            background = if (on) round(ACCENT, 72) else round(CARD2, 72)
            layoutParams = FrameLayout.LayoutParams(dp(152), dp(152)).apply { gravity = Gravity.CENTER }
            elevate(this, if (on) 8 else 0)
            setOnClickListener { prefs.edit().putBoolean("enabled", !on).apply(); show(0) }
        }
        btnWrap.addView(ring); btnWrap.addView(inner)
        p.addView(btnWrap)

        // status
        val sc = card()
        val acc = accessibilityOn()
        val srow = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        srow.addView(pill(
            if (!acc) "⚠ OFF" else if (on) "● ACTIVE" else "⏸ PAUSED",
            if (!acc) RED_DIM else if (on) GREEN_DIM else ACCENT_DIM,
            if (!acc) RED else if (on) GREEN else ACCENT))
        sc.addView(srow)
        sc.addView(text(
            if (!acc) "Accessibility OFF hai — yahan tap karo"
            else if (on) "Rapido par ride request ka wait kar raha hai"
            else "Upar ke button se ON karo", 13f, MUTED).apply { setPadding(0, dp(10), 0, 0) })
        sc.isClickable = true
        sc.setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        p.addView(sc)

        // stats
        val row = LinearLayout(this).apply {
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(14) }
        }
        fun stat(label: String, value: Int, color: Int, left: Boolean) = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            background = round(CARD, 18, BORDER)
            setPadding(dp(10), dp(18), dp(10), dp(18))
            elevate(this, 2)
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f).apply {
                if (left) rightMargin = dp(7) else leftMargin = dp(7)
            }
            addView(text(value.toString(), 32f, color, true))
            addView(text(label, 12f, MUTED).apply { setPadding(0, dp(4), 0, 0) })
        }
        row.addView(stat("Aaj accept", Store.todayCount(this, "count"), GREEN, true))
        row.addView(stat("Aaj skip", Store.todayCount(this, "skipCount"), RED, false))
        p.addView(row)

        // filters summary
        val fc = card()
        fc.addView(sectionLabel("ACTIVE FILTERS"))
        val f = prefs.getInt("minFare", 0)
        val mp = prefs.getFloat("maxPickup", 0f)
        val md = prefs.getFloat("maxDrop", 0f)
        fun filterRow(icon: String, label: String, value: String) = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(9), 0, dp(9))
            addView(text(icon, 15f))
            addView(text(label, 14f, MUTED).apply {
                setPadding(dp(10), 0, 0, 0)
                layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
            })
            addView(text(value, 15f, WHITE, true))
        }
        fc.addView(filterRow("₹", "Min fare", if (f == 0) "Any" else "₹$f"))
        fc.addView(View(this).apply { setBackgroundColor(BORDER); layoutParams = LinearLayout.LayoutParams(-1, dp(1)) })
        fc.addView(filterRow("📍", "Max pickup", if (mp == 0f) "Any" else "$mp km"))
        fc.addView(View(this).apply { setBackgroundColor(BORDER); layoutParams = LinearLayout.LayoutParams(-1, dp(1)) })
        fc.addView(filterRow("🏁", "Max drop", if (md == 0f) "Any" else "$md km"))
        p.addView(fc)
        return p
    }

    // ---------- generic stepper ----------
    private fun stepperCard(
        title: String, desc: String, get: () -> Float, set: (Float) -> Unit,
        step: Float, chips: List<Float>, fmt: (Float) -> String
    ): View {
        val c = card()
        c.addView(sectionLabel(title.uppercase()))
        val value = text(fmt(get()), 38f, WHITE, true).apply {
            gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
        }
        fun upd(v: Float) {
            val nv = maxOf(0f, Math.round(v * 10f) / 10f)
            set(nv); value.text = fmt(nv)
        }
        fun btn(label: String, d: Float) = TextView(this).apply {
            text = label; textSize = 24f; setTextColor(0xFF1A1300.toInt())
            setTypeface(null, Typeface.BOLD); gravity = Gravity.CENTER
            background = round(ACCENT, 26)
            layoutParams = LinearLayout.LayoutParams(dp(52), dp(52))
            elevate(this, 3)
            setOnClickListener { upd(get() + d) }
        }
        val row = LinearLayout(this).apply {
            gravity = Gravity.CENTER; setPadding(0, dp(12), 0, dp(12))
        }
        row.addView(btn("−", -step)); row.addView(value); row.addView(btn("+", step))
        c.addView(row)
        val cr = LinearLayout(this).apply { gravity = Gravity.CENTER }
        for (v in chips) {
            cr.addView(TextView(this).apply {
                text = fmt(v); textSize = 12.5f; setTextColor(ACCENT); gravity = Gravity.CENTER
                setTypeface(null, Typeface.BOLD)
                background = round(FIELD, 12, ACCENT_DIM)
                layoutParams = LinearLayout.LayoutParams(0, dp(38), 1f).apply {
                    leftMargin = dp(3); rightMargin = dp(3)
                }
                setOnClickListener { upd(v) }
            })
        }
        c.addView(cr)
        c.addView(text(desc, 12f, MUTED).apply { setPadding(0, dp(12), 0, 0) })
        return c
    }

    // ---------- FARE ----------
    private fun farePage(): View {
        val p = page("Fare", "Kam paise ki ride skip hogi")
        p.addView(stepperCard(
            "Minimum fare",
            "Is se kam fare wali ride accept nahi hogi. 'Any' = fare check band.",
            { prefs.getInt("minFare", 0).toFloat() },
            { prefs.edit().putInt("minFare", it.toInt()).apply() },
            5f, listOf(0f, 30f, 50f, 70f, 100f),
            { if (it.toInt() == 0) "Any" else "₹${it.toInt()}" }
        ))
        return p
    }

    // ---------- KM ----------
    private fun kmPage(): View {
        val p = page("Distance (KM)", "Pickup aur drop ki doori set karo")
        p.addView(stepperCard(
            "Max pickup distance",
            "Customer is se zyada door ho to ride skip hogi. 'Any' = check band.",
            { prefs.getFloat("maxPickup", 0f) },
            { prefs.edit().putFloat("maxPickup", it).apply() },
            0.5f, listOf(0f, 1f, 2f, 3f, 5f),
            { if (it == 0f) "Any" else "$it km" }
        ))
        p.addView(stepperCard(
            "Max drop distance",
            "Safar is se lamba ho to ride skip hogi. 'Any' = check band.",
            { prefs.getFloat("maxDrop", 0f) },
            { prefs.edit().putFloat("maxDrop", it).apply() },
            1f, listOf(0f, 5f, 10f, 20f, 40f),
            { if (it == 0f) "Any" else "$it km" }
        ))
        val note = card()
        note.addView(LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            addView(text("ℹ️", 14f))
            addView(text("Screen par pehla km = pickup, dusra km = drop maana jata hai.", 12.5f, MUTED).apply {
                setPadding(dp(10), 0, 0, 0)
            })
        })
        p.addView(note)
        return p
    }

    // ---------- HISTORY ----------
    private fun historyPage(): View {
        val p = page("History", "Accept aur skip hui rides")
        val items = Store.history(this)
        if (items.isEmpty()) {
            val c = card(pad = 26)
            c.gravity = Gravity.CENTER
            c.addView(text("🕘", 30f).apply { gravity = Gravity.CENTER })
            c.addView(text("Abhi koi ride nahi", 15f, MUTED, true).apply {
                gravity = Gravity.CENTER; setPadding(0, dp(8), 0, 0)
            })
            p.addView(c)
            return p
        }
        val fmt = SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault())
        for (h in items) {
            val ok = h[0] == "A"
            val c = card()
            val r = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
            val left = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
            }
            val km = listOf(
                if (h[3].isNotEmpty()) "📍 ${h[3]} km" else "",
                if (h[4].isNotEmpty()) "🏁 ${h[4]} km" else ""
            ).filter { it.isNotEmpty() }.joinToString("   ")
            left.addView(text("₹${h[2]}", 19f, WHITE, true))
            if (km.isNotEmpty()) left.addView(text(km, 12.5f, MUTED).apply { setPadding(0, dp(2), 0, 0) })
            left.addView(text(fmt.format(Date(h[1].toLongOrNull() ?: 0L)), 11.5f, MUTED).apply { setPadding(0, dp(6), 0, 0) })
            r.addView(left)
            r.addView(pill(if (ok) "✔ Accepted" else "✖ ${h[5]}", if (ok) GREEN_DIM else RED_DIM, if (ok) GREEN else RED))
            c.addView(r)
            p.addView(c)
        }
        p.addView(actionBtn("🗑", "History clear karo", RED) {
            Store.clearHistory(this); show(3)
        })
        return p
    }

    // ---------- SETTINGS ----------
    private fun toggleRow(title: String, sub: String, key: String, def: Boolean): View {
        val c = card()
        val r = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
        }
        col.addView(text(title, 15.5f, WHITE, true))
        col.addView(text(sub, 12.5f, MUTED).apply { setPadding(0, dp(2), 0, 0) })
        val sw = Switch(this).apply {
            isChecked = prefs.getBoolean(key, def)
            thumbTintList = ColorStateList(
                arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()),
                intArrayOf(ACCENT, 0xFF888888.toInt()))
            trackTintList = ColorStateList(
                arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()),
                intArrayOf(ACCENT_DIM, 0xFF333640.toInt()))
            setOnCheckedChangeListener { _, v -> prefs.edit().putBoolean(key, v).apply() }
        }
        r.addView(col); r.addView(sw)
        c.addView(r)
        return c
    }

    private fun settingsPage(): View {
        val p = page("Settings", "App ki settings")

        p.addView(toggleRow("Vibrate", "Ride accept hone par phone vibrate kare", "vibrate", true))

        val pc = card()
        pc.addView(sectionLabel("RAPIDO PACKAGE NAME"))
        val box = EditText(this).apply {
            setText(prefs.getString("pkg", "com.rapido.rider"))
            setTextColor(WHITE); textSize = 14.5f
            background = round(FIELD, 12, BORDER)
            setPadding(dp(14), dp(12), dp(14), dp(12))
            setSingleLine(true)
            addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(s: Editable?) {
                    prefs.edit().putString("pkg", s.toString().trim()).apply()
                }
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            })
        }
        pc.addView(box.apply {
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) }
        })
        pc.addView(text("Naam mein 'rapido' ho to apne aap chalega. Na chale to yahan sahi naam daalo.", 12f, MUTED)
            .apply { setPadding(0, dp(10), 0, 0) })
        p.addView(pc)

        p.addView(actionBtn("♿", "Accessibility Settings") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        p.addView(actionBtn("🔋", "Battery: No restrictions karo") {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        })
        p.addView(actionBtn("🔄", "Aaj ke counter reset karo") {
            Store.resetToday(this); Toast.makeText(this, "Reset ho gaya", Toast.LENGTH_SHORT).show()
        })

        // ---- DEBUG CARD ----
        val dc = card()
        val dhead = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        dhead.addView(text("🛠", 15f))
        dhead.addView(text("DEBUG", 13f, MUTED, true, 0.06f).apply {
            setPadding(dp(8), 0, 0, 0)
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
        })
        dc.addView(dhead)
        dc.addView(text("Ride na accept ho to yahan dekho", 12f, MUTED).apply { setPadding(0, dp(2), 0, dp(10)) })

        val lastPkg = prefs.getString("lastPkg", "") ?: ""
        val lastPkgTime = prefs.getLong("lastPkgTime", 0L)
        val ago1 = if (lastPkgTime > 0) ((System.currentTimeMillis() - lastPkgTime) / 1000) else -1
        dc.addView(text("Abhi khula hua app", 12.5f, MUTED))
        dc.addView(text(if (lastPkg.isEmpty()) "(abhi tak kuch nahi dekha)" else "$lastPkg  (${ago1}s pehle)", 13.5f, WHITE, true)
            .apply { setPadding(0, dp(2), 0, dp(12)) })

        val dump = prefs.getString("lastDump", "") ?: ""
        val found = prefs.getBoolean("lastFound", false)
        val dumpTime = prefs.getLong("lastDumpTime", 0L)
        val winCount = prefs.getInt("lastWindowCount", -1)
        dc.addView(text("Accept button mila (windows: " + (if (winCount < 0) "-" else winCount.toString()) + ")", 12.5f, MUTED))
        dc.addView(pill(
            if (dumpTime == 0L) "— Rapido nahi dekha" else if (found) "✅ HAAN" else "❌ NAHI",
            if (dumpTime == 0L) FIELD else if (found) GREEN_DIM else RED_DIM,
            if (dumpTime == 0L) MUTED else if (found) GREEN else RED
        ).apply { layoutParams = LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(4); bottomMargin = dp(12) } })

        dc.addView(text("Screen par dikha text (sample)", 12.5f, MUTED))
        dc.addView(text(if (dump.isEmpty()) "(kuch nahi mila)" else dump, 12f, 0xFFC9CDD6.toInt())
            .apply { setPadding(0, dp(4), 0, 0) })

        dc.addView(actionBtn("🔄", "Refresh debug info") { show(4) })
        p.addView(dc)

        val foot = LinearLayout(this).apply {
            gravity = Gravity.CENTER
            setPadding(0, dp(22), 0, 0)
        }
        foot.addView(text("⚡ Ride Helper", 12.5f, MUTED, true))
        foot.addView(text("  •  v2.1", 12.5f, MUTED))
        p.addView(foot)
        return p
    }
}
