package com.myhelper.ride

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class AutoAcceptService : AccessibilityService() {

    // Rapido Captain app ka package. Agar kaam na kare to MainActivity mein diya package check karna.
    private val targetPackages = setOf("com.rapido.rider", "com.rapido.captain")
    private val acceptTexts = listOf("accept", "स्वीकार करें", "स्वीकार")
    private var lastClick = 0L

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val pkg = event?.packageName?.toString() ?: return
        if (pkg !in targetPackages) return

        val prefs = getSharedPreferences("cfg", MODE_PRIVATE)
        if (!prefs.getBoolean("enabled", false)) return

        val now = System.currentTimeMillis()
        if (now - lastClick < 1500) return

        val root = rootInActiveWindow ?: return
        val button = findAccept(root) ?: return

        val minFare = prefs.getInt("minFare", 0)
        if (minFare > 0) {
            val fare = maxFare(root)
            if (fare < minFare) return   // fare kam hai, skip
        }

        if (clickNode(button)) lastClick = now
    }

    private fun findAccept(node: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        val t = node.text?.toString()?.trim()?.lowercase()
        if (t != null && acceptTexts.any { t == it }) return node
        for (i in 0 until node.childCount) {
            val c = node.getChild(i) ?: continue
            findAccept(c)?.let { return it }
        }
        return null
    }

    private fun maxFare(node: AccessibilityNodeInfo): Int {
        var best = 0
        val t = node.text?.toString()
        if (t != null && t.contains("₹")) {
            Regex("₹\\s*(\\d+)").findAll(t).forEach {
                best = maxOf(best, it.groupValues[1].toInt())
            }
        }
        for (i in 0 until node.childCount) {
            val c = node.getChild(i) ?: continue
            best = maxOf(best, maxFare(c))
        }
        return best
    }

    private fun clickNode(n: AccessibilityNodeInfo): Boolean {
        var cur: AccessibilityNodeInfo? = n
        while (cur != null) {
            if (cur.isClickable) return cur.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            cur = cur.parent
        }
        return false
    }

    override fun onInterrupt() {}
}
