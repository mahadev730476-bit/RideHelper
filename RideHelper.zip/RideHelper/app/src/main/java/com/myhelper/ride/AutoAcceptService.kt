package com.myhelper.ride

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.os.Vibrator
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class AutoAcceptService : AccessibilityService() {

    private val acceptTexts = listOf("accept", "स्वीकार करें", "स्वीकार")
    private val kmRe = Regex("^\\s*(\\d+(?:\\.\\d+)?)\\s*km\\b", RegexOption.IGNORE_CASE)
    private val fareRe = Regex("₹\\s*(\\d+)")
    private var lastClick = 0L
    private var lastSkipSig = ""
    private var lastSkipTime = 0L

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val pkg = event?.packageName?.toString() ?: return
        val prefs = Store.prefs(this)
        val target = prefs.getString("pkg", "com.rapido.rider")?.trim().orEmpty()
        if (!(pkg.contains("rapido", true) || (target.isNotEmpty() && pkg == target))) return
        if (!prefs.getBoolean("enabled", false)) return

        val now = System.currentTimeMillis()
        if (now - lastClick < 1500) return

        val root = rootInActiveWindow ?: return
        val button = findAccept(root) ?: return

        var fare = 0
        val kms = ArrayList<Double>()
        collect(root) { t ->
            fareRe.findAll(t).forEach { fare = maxOf(fare, it.groupValues[1].toInt()) }
            kmRe.find(t)?.let { kms.add(it.groupValues[1].toDouble()) }
        }
        val pickup = kms.getOrNull(0)
        val drop = kms.getOrNull(1)
        val pStr = pickup?.toString() ?: ""
        val dStr = drop?.toString() ?: ""

        val minFare = prefs.getInt("minFare", 0)
        val maxPickup = prefs.getFloat("maxPickup", 0f)
        val maxDrop = prefs.getFloat("maxDrop", 0f)

        var reason: String? = null
        if (minFare > 0 && fare < minFare) reason = "Fare kam (₹$fare)"
        else if (maxPickup > 0f && pickup != null && pickup > maxPickup) reason = "Pickup door ($pStr km)"
        else if (maxDrop > 0f && drop != null && drop > maxDrop) reason = "Drop door ($dStr km)"

        if (reason != null) {
            val sig = "$fare|$pStr|$dStr|$reason"
            if (sig != lastSkipSig || now - lastSkipTime > 8000) {
                lastSkipSig = sig
                lastSkipTime = now
                Store.bump(this, "skipCount")
                Store.addHistory(this, "S", fare, pStr, dStr, reason)
            }
            return
        }

        if (clickNode(button)) {
            lastClick = now
            Store.bump(this, "count")
            Store.addHistory(this, "A", fare, pStr, dStr, "Accepted")
            if (prefs.getBoolean("vibrate", true)) {
                @Suppress("DEPRECATION")
                (getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator)?.vibrate(150L)
            }
        }
    }

    private fun collect(node: AccessibilityNodeInfo, f: (String) -> Unit) {
        node.text?.toString()?.let { f(it) }
        for (i in 0 until node.childCount) {
            val c = node.getChild(i) ?: continue
            collect(c, f)
        }
    }

    private fun findAccept(node: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        val t = node.text?.toString()?.trim()?.lowercase()
        if (t != null && acceptTexts.any { t == it }) return node
        for (i in 0 until node.childCount) {
            val c = node.getChild(i) ?: continue
            findAccept(c)?.let { return it }
        }
        return null
    }

    private fun clickNode(n: AccessibilityNodeInfo): Boolean {
        var cur: AccessibilityNodeInfo? = n
        while (cur != null) {
            if (cur.isClickable) return cur.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            cur = cur.parent
        }
        return false
    }

    override fun onInterrupt() {}
}
