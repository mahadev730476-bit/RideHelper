package com.myhelper.ride

import android.content.Context
import java.text.SimpleDateFormat
import java.util.*

object Store {
    fun prefs(c: Context) = c.getSharedPreferences("cfg", Context.MODE_PRIVATE)

    private fun today() = SimpleDateFormat("yyyyMMdd", Locale.US).format(Date())

    fun bump(c: Context, key: String) {
        val p = prefs(c)
        val e = p.edit()
        val fresh = p.getString("countDate", "") != today()
        if (fresh) e.putString("countDate", today()).putInt("count", 0).putInt("skipCount", 0)
        val base = if (fresh) 0 else p.getInt(key, 0)
        e.putInt(key, base + 1).apply()
    }

    fun todayCount(c: Context, key: String): Int {
        val p = prefs(c)
        return if (p.getString("countDate", "") == today()) p.getInt(key, 0) else 0
    }

    fun resetToday(c: Context) {
        prefs(c).edit().putInt("count", 0).putInt("skipCount", 0).apply()
    }

    // type: A (accepted) / S (skipped)
    fun addHistory(c: Context, type: String, fare: Int, pickup: String, drop: String, note: String) {
        val p = prefs(c)
        val line = listOf(type, System.currentTimeMillis().toString(), fare.toString(),
            pickup, drop, note.replace("|", " ")).joinToString("|")
        val old = (p.getString("history", "") ?: "").split("\n").filter { it.isNotBlank() }
        p.edit().putString("history", (listOf(line) + old).take(80).joinToString("\n")).apply()
    }

    fun history(c: Context): List<List<String>> =
        (prefs(c).getString("history", "") ?: "").split("\n")
            .filter { it.isNotBlank() }.map { it.split("|") }.filter { it.size >= 6 }

    fun clearHistory(c: Context) {
        prefs(c).edit().remove("history").apply()
    }
}
